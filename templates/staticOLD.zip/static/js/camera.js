top-part.addEventListener("submit", (e) => {
    e.preventDefault();
  
    // handle submit
  });
  
  
  top-part.addEventListener("submit", (e) => {
    e.preventDefault();
  
    // handle submit
  });

  //added this again